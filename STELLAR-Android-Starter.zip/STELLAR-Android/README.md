# STELLAR for Android

A privacy-first browser prototype using Mozilla GeckoView.

## Current scope

Implemented in this starter:
- Native Android activity and simple browser controls
- GeckoView browser engine
- Gecko private session mode
- Search/address normalization that only accepts HTTP(S)
- No app analytics, ads SDK, accounts, sync service, or first-party backend
- Android backup disabled and cleartext traffic disabled
- Basic unit tests for URL normalization

Not implemented and NOT safe to claim yet:
- Tor routing, Tor isolation, or fail-closed behavior
- Complete tracker/ad blocking
- Verified DNS/IP/WebRTC leak prevention
- Download sandbox and download scanning
- Full cookie/cache/session deletion audit
- Independent security audit
- Release signing and reproducible build verification

The "Clear" button replaces the current private session. This is a prototype behavior, not a guarantee that every artifact is erased from every layer of the operating system or browser engine.

## Build

Requirements:
- Android Studio with Android SDK 36
- JDK 17
- Internet access to download Gradle and Mozilla Maven dependencies

Open this directory in Android Studio and sync Gradle, then run the `app` configuration on an Android device or emulator.

Command line (from this directory):
```bash
gradle testDebugUnitTest
gradle assembleDebug
```

The environment used to create this starter has not run an Android/Gradle build. Treat the first build as unverified until those commands succeed.

## Privacy notes

The app has no first-party server, analytics, account system, or telemetry implementation. The browser engine and websites still make network requests. GeckoView private mode is not equivalent to Tor and does not hide your IP address from websites or your internet provider.

The search provider receives searches when used. Website operators can see requests to their own sites. This project does not promise anonymity.

## Security work before public release

1. Verify GeckoView dependency version and review Mozilla security advisories.
2. Run Gradle dependency verification and produce an SBOM.
3. Audit all network requests on clean install, first launch, navigation, crash, and update.
4. Test persistence across force-stop, process death, reboot, and reinstall.
5. Implement and independently test tracker blocking.
6. Design Tor as a separate audited milestone; never silently fall back from Tor to direct networking.
7. Test TLS errors, redirects, downloads, external intents, permissions, and URL parsing.
8. Commission independent review before making strong privacy claims.

## License

This project starter is provided for development. Review all third-party licenses before distribution.
