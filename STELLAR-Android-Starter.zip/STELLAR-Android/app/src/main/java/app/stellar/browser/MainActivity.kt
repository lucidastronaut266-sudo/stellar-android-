package app.stellar.browser

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView

/**
 * STELLAR prototype. Private GeckoSession mode is enabled.
 * This is not yet an audited anonymity browser and does not implement Tor or full tracker blocking.
 */
class MainActivity : Activity() {
    private lateinit var runtime: GeckoRuntime
    private lateinit var session: GeckoSession
    private lateinit var browserView: GeckoView
    private lateinit var address: EditText
    private lateinit var status: TextView
    private var torEnabled = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(17, 21, 26)
        window.navigationBarColor = Color.rgb(17, 21, 26)
        window.decorView.systemUiVisibility = 0

        runtime = GeckoRuntime.getDefault(this)
        buildUi()
        createPrivateSession()
        session.loadUri("https://duckduckgo.com/")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(17, 21, 26))
            setPadding(dp(12), dp(12), dp(12), dp(8))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "✦  STELLAR"
            textSize = 22f
            setTextColor(Color.rgb(214, 245, 181))
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        header.addView(brand, LinearLayout.LayoutParams(0, dp(44), 1f))

        val privacy = Button(this).apply {
            text = "Privacy"
            isAllCaps = false
            setOnClickListener { showPrivacyStatus() }
        }
        header.addView(privacy)
        root.addView(header)

        address = EditText(this).apply {
            hint = "Search privately or enter address"
            singleLine = true
            textSize = 15f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(dp(14), 0, dp(14), 0)
            background = rounded(Color.rgb(34, 40, 48), dp(14))
            setSelectAllOnFocus(false)
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_GO ||
                    actionId == EditorInfo.IME_ACTION_DONE) {
                    navigateFromAddress()
                    true
                } else false
            }
        }
        val addressParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(50)
        ).apply { topMargin = dp(10); bottomMargin = dp(8) }
        root.addView(address, addressParams)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        controls.addView(actionButton("Back") { if (::session.isInitialized && session.isOpen) session.goBack() })
        controls.addView(actionButton("Forward") { if (::session.isInitialized && session.isOpen) session.goForward() })
        controls.addView(actionButton("Home") { session.loadUri("https://duckduckgo.com/") })
        controls.addView(actionButton("Clear") { clearSession() })
        root.addView(controls)

        status = TextView(this).apply {
            text = "Private session • Tor is not connected"
            textSize = 12f
            setTextColor(Color.rgb(214, 245, 181))
            setPadding(dp(4), dp(8), dp(4), dp(8))
        }
        root.addView(status)

        browserView = GeckoView(this)
        root.addView(browserView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(root)
    }

    private fun createPrivateSession() {
        session = GeckoSession(
            GeckoSessionSettings.Builder()
                .usePrivateMode(true)
                .build()
        )
        session.open(runtime)
        browserView.setSession(session)
    }

    private fun navigateFromAddress() {
        val raw = address.text.toString().trim()
        if (raw.isBlank()) return
        val url = UrlRules.toNavigationUrl(raw)
        if (url == null) {
            Toast.makeText(this, "That address is not supported.", Toast.LENGTH_SHORT).show()
            return
        }
        address.clearFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(address.windowToken, 0)
        session.loadUri(url)
    }

    private fun clearSession() {
        // GeckoView private sessions are designed not to persist normal browsing data.
        // Closing and replacing the session also drops its in-memory session state.
        try {
            browserView.releaseSession()
            session.close()
        } catch (_: Exception) {
            // Best-effort cleanup; report no stronger guarantee than the engine provides.
        }
        createPrivateSession()
        address.setText("")
        session.loadUri("about:blank")
        status.text = "New private session • Tor is not connected"
        Toast.makeText(this, "Private session reset", Toast.LENGTH_SHORT).show()
    }

    private fun showPrivacyStatus() {
        val message = if (torEnabled) {
            "Tor status is not verified. Do not use this prototype for anonymity."
        } else {
            "Private session is enabled. Tor is not implemented. Your network provider and websites may still see connection data."
        }
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun actionButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 12f
            setPadding(dp(2), 0, dp(2), 0)
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
        }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        try {
            if (::browserView.isInitialized) browserView.releaseSession()
            if (::session.isInitialized) session.close()
        } catch (_: Exception) { }
        super.onDestroy()
    }
}
