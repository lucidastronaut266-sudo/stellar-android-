package app.stellar.browser

import android.util.Patterns
import java.net.URI
import java.util.Locale

/**
 * Conservative address normalization. Only HTTP(S) destinations are accepted.
 * Bare words are sent to the configured search provider.
 */
object UrlRules {
    fun toNavigationUrl(input: String): String? {
        val value = input.trim()
        if (value.isEmpty()) return null
        if (value.any { it.isISOControl() }) return null

        val hasScheme = Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:").containsMatchIn(value)
        if (hasScheme) {
            val uri = try { URI(value) } catch (_: Exception) { return null }
            val scheme = uri.scheme?.lowercase(Locale.ROOT) ?: return null
            if (scheme != "https" && scheme != "http") return null
            if (uri.host.isNullOrBlank()) return null
            if (uri.userInfo != null) return null
            return uri.toASCIIString()
        }

        if (value.contains(' ') || !value.contains('.')) {
            return "https://duckduckgo.com/?q=" + value
                .replace("%", "%25")
                .replace(" ", "+")
        }

        val candidate = "https://$value"
        val uri = try { URI(candidate) } catch (_: Exception) { return null }
        if (uri.host.isNullOrBlank() || uri.userInfo != null) return null
        return uri.toASCIIString()
    }
}
