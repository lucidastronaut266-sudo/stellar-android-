package app.stellar.browser

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class UrlRulesTest {
    @Test fun acceptsHttps() {
        assertEquals("https://example.com", UrlRules.toNavigationUrl("https://example.com"))
    }

    @Test fun addsHttpsToBareHost() {
        assertEquals("https://example.com", UrlRules.toNavigationUrl("example.com"))
    }

    @Test fun sendsSearchTermsToSearchEngine() {
        assertEquals("https://duckduckgo.com/?q=hello+world",
            UrlRules.toNavigationUrl("hello world"))
    }

    @Test fun rejectsJavascriptScheme() {
        assertNull(UrlRules.toNavigationUrl("javascript:alert(1)"))
    }

    @Test fun rejectsFileScheme() {
        assertNull(UrlRules.toNavigationUrl("file:///etc/passwd"))
    }

    @Test fun rejectsUserInfoUrls() {
        assertNull(UrlRules.toNavigationUrl("https://user:pass@example.com"))
    }

    @Test fun rejectsControlCharacters() {
        assertNull(UrlRules.toNavigationUrl("https://example.com\\nmalicious"))
    }
}
