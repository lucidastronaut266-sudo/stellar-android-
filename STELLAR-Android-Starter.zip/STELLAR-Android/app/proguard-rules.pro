# Keep GeckoView's native integration intact. Review Mozilla's release-specific guidance
# before enabling additional shrinking/obfuscation rules for production builds.
